Change Log :

== 2.0.1 ==
- [IMPROVEMENT] Use modified date instead creation date on post meta date
- [BUG] Fix issue with the latest version of AMP for WordPress plugin

== 2.0.0 ==
- [IMPROVEMENT] Support Google Auto Ads on AMP pages
- [IMPROVEMENT] Compatible with JNews v2.0.0

== 1.0.5 ==
- [IMPROVEMENT] Use background color from Customizer
- [BUG] Fix issue with Publisher ID of Google Ads

== 1.0.4 ==
- [IMPROVEMENT] Add Google Ads as default ads

== 1.0.3 ==
- [IMPROVEMENT] Add custom ads option

== 1.0.2 ==
- [IMPROVEMENT] Better handler for post featured image
- [BUG] Fix Google font issue

== 1.0.1 ==
- [BUG] Fix hook function issue

== 1.0.0 ==
- First Release