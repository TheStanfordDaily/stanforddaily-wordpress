<?php
/**
 * @author Jegtheme
 */

if ( ! defined( 'ABSPATH' ) ) 
{
    exit;
}

Class JNews_Frontend_Option
{
    private static $instance;

    private $customizer;

    public static function getInstance()
    {
        if ( null === static::$instance )
        {
            static::$instance = new static();
        }
        return static::$instance;
    }

    private function __construct()
    {
        if ( class_exists('Jeg\Customizer') )
        {
            $this->customizer = Jeg\Customizer::getInstance();

            $this->set_panel();
            $this->set_section();
            $this->set_field();
        }
    }

    public function set_panel()
    {
        $this->customizer->add_panel(array(
            'id' => 'jnews_frontend_submit_panel',
            'title' => esc_html__('JNews : Frontend Submit', 'jnews-frontend-submit'),
            'description' => esc_html__('Frontend Submit Article Setting', 'jnews-frontend-submit'),
            'priority' => 200
        ));
    }

    public function set_section()
    {
        $this->customizer->add_section(array(
            'id' => 'jnews_frontend_submit_section',
            'title' => esc_html__('Frontend Submit Setting', 'jnews-frontend-submit'),
            'panel' => 'jnews_frontend_submit_panel',
            'priority' => 262,
        ));
    }

    public function set_field()
    {
        $this->customizer->add_field(array(
            'id'            => 'jnews_frontend_submit_tab_header_1',
            'type'          => 'jnews-header',
            'section'       => 'jnews_frontend_submit_section',
            'label'         => esc_html__('General Option','jnews-frontend-submit' ),
        ));

        $this->customizer->add_field(array(
            'id'            => 'jnews_frontend_submit_enable_add_media',
            'transport'     => 'postMessage',
            'default'       => true,
            'type'          => 'jnews-toggle',
            'section'       => 'jnews_frontend_submit_section',
            'label'         => esc_html__('Enable Add Media', 'jnews-frontend-submit'),
            'description'   => esc_html__('Enable add media button on frontend post editor.', 'jnews-frontend-submit'),
        ));

        $this->customizer->add_field(array(
            'id'            => 'jnews_frontend_submit_maxupload',
            'transport'     => 'postMessage',
            'default'       => '2',
            'type'          => 'jnews-slider',
            'section'       => 'jnews_frontend_submit_section',
            'label'         => esc_html__('Maxupload Size', 'jnews'),
            'description'   => esc_html__('Set maxupload file size.', 'jnews'),
            'choices'       => array(
                'min'  => '1',
                'max'  => '10',
                'step' => '1',
            )
        ));

        $this->customizer->add_field(array(
            'id'            => 'jnews_frontend_submit_tab_header_2',
            'type'          => 'jnews-header',
            'section'       => 'jnews_frontend_submit_section',
            'label'         => esc_html__('Advanced Option','jnews-frontend-submit' ),
        ));

        $this->customizer->add_field(array(
            'id'            => 'jnews_frontend_submit_enable_woocommerce',
            'transport'     => 'postMessage',
            'default'       => false,
            'type'          => 'jnews-toggle',
            'section'       => 'jnews_frontend_submit_section',
            'label'         => esc_html__('Enable WooCommerce Mode', 'jnews-frontend-submit'),
            'description'   => esc_html__('By enabling this option, the site user will need to buy post package before they can submit their post using frontend submit.', 'jnews-frontend-submit'),
        ));
    }
}