Change Log :

== 2.0.2 ==
- [BUG] Fix undefined label index issue on account page

== 2.0.1 ==
- [IMPROVEMENT] Use modified date instead creation date on post meta date

== 2.0.0 ==
- [IMPROVEMENT] Compatible with JNews v2.0.0

== 1.0.0 ==
- First Release