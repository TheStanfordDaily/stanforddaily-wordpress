Change Log :

== 2.0.1 ==
- [IMPROVEMENT] Support Instagram API to fetch Instagram feed
- [BUG] Fixed Instagram feed issue

== 2.0.0 ==
- [IMPROVEMENT] Compatible with JNews v2.0.0

== 1.0.1 ==
- [BUG] Fix feed issue

== 1.0.0 ==
- First Release