Change Log :

== 2.0.0 ==
- [IMPROVEMENT] Compatible with JNews v2.0.0

== 1.0.2 ==
- [BUG] Fix round number issue

== 1.0.1 ==
- [BUG] Fix wrong file name

== 1.0.0 ==
- First Release