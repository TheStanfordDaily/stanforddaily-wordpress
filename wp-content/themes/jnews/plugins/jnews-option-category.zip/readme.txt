Change Log :

== 2.0.0 ==
- [IMPROVEMENT] Compatible with JNews v2.0.0

== 1.0.1 ==
- [IMPROVEMENT] Add page layout option

== 1.0.0 ==
- First Release