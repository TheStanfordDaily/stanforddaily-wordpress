Change Log :

== 2.0.0 ==
- [IMPROVEMENT] Compatible with JNews v2.0.0

== 1.1.0 ==
- Add capability to add review without rating

== 1.0.0 ==
- First Release